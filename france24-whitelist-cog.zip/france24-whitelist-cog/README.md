# France24Whitelist

A [Red-DiscordBot](https://github.com/Cog-Creators/Red-DiscordBot) (v3.5+) cog that keeps only
regular **France 24 news articles** in your channels.

It only ever looks at messages that contain a France 24 link. Links to any other website, and
ordinary messages, are never touched. RSS/webhook/bot posts are checked too, including links
inside their embeds.

## What counts as allowed

By default an allowed link looks like `/en/<section>/<8-digit date>-<headline>`:

| Link | Result |
|---|---|
| `https://www.france24.com/en/europe/20261004-bosnia-votes...` | allowed |
| `https://www.france24.com/en/tv-shows/access-asia/20261002-...` | **blocked** (show episode) |
| `https://www.france24.com/en/video/20260928-thailand-floods...` | **blocked** (video clip) |
| `https://www.france24.com/en/thousands-evacuated-amid-bangkok-floods` | **blocked** (newscast item) |
| `https://www.bbc.com/news/...` | ignored |
| `https://s.france24.com/media/display/.../photo.jpg` | ignored (only `france24.com` and `www.france24.com` are checked) |

Allowed sections: `asia-pacific`, `europe`, `africa`, `middle-east`, `americas`, `france`.
Change this with `[p]f24wl pattern`.

## Install

```
[p]repo add france24-cogs https://github.com/YOUR_GITHUB_USERNAME/france24-whitelist-cog
[p]cog install france24-cogs france24whitelist
[p]load france24whitelist
```

The bot needs **Manage Messages** in the channels it checks.

## Setup

Start in dry-run mode so you can see what would be deleted before anything is:

```
[p]f24wl channels add #asia-pacific #europe
[p]f24wl logchannel #bot-log
[p]f24wl dryrun true
[p]f24wl enable
```

Check the log channel for a while, then run `[p]f24wl dryrun false`.

## Commands

All commands need Manage Server (or admin). `[p]f24wl` is short for `[p]france24whitelist`.

| Command | What it does |
|---|---|
| `[p]f24wl enable` / `disable` | Turn the whitelist on or off (default: off) |
| `[p]f24wl dryrun <true/false>` | Only log, never delete |
| `[p]f24wl channels add/remove/clear/list` | Limit which channels are checked (none set = all channels) |
| `[p]f24wl logchannel [channel]` | Log blocked links to a channel; no argument turns logging off |
| `[p]f24wl exemptmods <true/false>` | Let human mods/admins/owner post any link (default: true) |
| `[p]f24wl pattern [regex]` | Show or set the regex the URL *path* must match |
| `[p]f24wl pattern reset` | Restore the default pattern |
| `[p]f24wl test <url>` | Show what would happen to a link |
| `[p]f24wl settings` | Show the current settings |

## Good to know

- **The whole message is deleted** when it contains a blocked France 24 link. A bot's embed
  can't be edited, so removing the message is the only option. Messages without a blocked
  France 24 link are left alone.
- Bots and webhooks are never exempt, which is what you want for RSS posts. Only human
  moderators are, and only when `exemptmods` is on.
- Shortened links (e.g. `f24.my/...`) are not expanded, so they are not checked.
- If the regex is invalid, the cog fails open and deletes nothing.
- Threads are covered by their parent channel's setting.

## Development

The URL logic lives in `france24whitelist/matching.py` and has no Discord dependency:

```
pip install pytest
pytest
```

## License

MIT, see [LICENSE](LICENSE).
