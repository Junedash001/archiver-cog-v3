"""Run with: pytest  (no Red or Discord install needed)."""
import importlib.util
import pathlib

import pytest

_path = pathlib.Path(__file__).parent.parent / "france24whitelist" / "matching.py"
_spec = importlib.util.spec_from_file_location("matching", _path)
m = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(m)

PATTERN = m.compile_pattern(m.DEFAULT_PATTERN)
F = "https://www.france24.com"


def verdicts(text):
    return [m.classify(u, PATTERN) for u in m.find_urls(text)]


@pytest.mark.parametrize(
    "url",
    [
        f"{F}/en/asia-pacific/20261003-north-korea-fires-ballistic-missile-after-seoul-s-apology-demand",
        f"{F}/en/europe/20261004-live-germany-s-merz-in-kyiv-for-talks-with-zelensky",
        f"{F}/en/europe/20261004-foo?ref=rss",
        f"{F}/en/europe/20261004-foo#section",
        f"{F}:443/en/europe/20261004-foo",
        "HTTPS://WWW.FRANCE24.COM/en/europe/20261004-foo",
        "https://france24.com/en/africa/20261004-foo",
    ],
)
def test_allowed_articles(url):
    assert verdicts(url) == [m.ALLOW]


@pytest.mark.parametrize(
    "url",
    [
        f"{F}/en/tv-shows/access-asia/20261002-make-our-streets-safer-mass-women-s-protests-sweep-india",
        f"{F}/en/video/20260928-thailand-floods-at-least-8-die-thousands-move-to-shelters",
        f"{F}/en/thousands-evacuated-amid-bangkok-floods",
        f"{F}/en/china-projecting-image-of-stabilising-force-in-world-politics-expert-says",
        f"{F}/en/europe/",
        f"{F}/en/europe",
        f"{F}",
        f"{F}/fr/europe/20261004-foo",
    ],
)
def test_blocked(url):
    assert verdicts(url) == [m.BLOCK]


@pytest.mark.parametrize(
    "text",
    [
        "hello world, no links here",
        "https://www.bbc.com/news/world-asia-123",
        "https://s.france24.com/media/display/abc/photo.jpg",
        "https://static.france24.com/x.js",
        "https://notfrance24.com/en/video/20261004-foo",
        "https://france24.com.evil.io/en/video/20261004-foo",
        "https://example.com/?u=https://www.france24.com/en/video/1",
        "mail me at someone@france24.com",
        "france24.company is not it",
        "static.france24.com/en/video/1",
    ],
)
def test_other_links_and_text_are_ignored(text):
    assert [v for v in verdicts(text) if v != m.IGNORE] == []


def test_markdown_masked_and_spoiler_links():
    assert verdicts(f"[read]({F}/en/video/20261004-foo)") == [m.BLOCK]
    assert verdicts(f"[{F}/en/tv-shows/x/1]({F}/en/tv-shows/x/1)") == [m.BLOCK, m.BLOCK]
    assert verdicts(f"<{F}/en/video/20261004-foo>") == [m.BLOCK]
    assert verdicts(f"||{F}/en/video/20261004-foo||") == [m.BLOCK]
    assert verdicts(f"**{F}/en/europe/20261004-foo**") == [m.ALLOW]


def test_trailing_punctuation_is_stripped():
    assert verdicts(f"see {F}/en/europe/20261004-foo.") == [m.ALLOW]
    assert verdicts(f"({F}/en/europe/20261004-foo), thanks") == [m.ALLOW]


def test_bare_domain_links():
    assert verdicts("france24.com/en/video/20261004-foo") == [m.BLOCK]
    assert verdicts("www.france24.com/en/europe/20261004-foo") == [m.ALLOW]


def test_mixed_message_has_blocked_link():
    text = f"{F}/en/europe/20261004-foo and https://example.com and {F}/en/video/2026-x"
    assert verdicts(text) == [m.ALLOW, m.IGNORE, m.BLOCK]


def test_no_double_counting_scheme_links():
    assert len(m.find_urls(f"{F}/en/video/1")) == 1


def test_empty_and_none():
    assert m.find_urls(None) == []
    assert m.find_urls("") == []


def test_custom_pattern():
    p = m.compile_pattern(r"^/en/(?:europe)/\d{8}-")
    assert m.classify(f"{F}/en/asia-pacific/20261003-x", p) == m.BLOCK
    assert m.classify(f"{F}/en/europe/20261003-x", p) == m.ALLOW
